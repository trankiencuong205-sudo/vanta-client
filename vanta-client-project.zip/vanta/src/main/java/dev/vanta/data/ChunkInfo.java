package dev.vanta.data;

/** Everything the client has learned about one chunk from the data it received from the server. */
public final class ChunkInfo {
    public enum Status {NEW, OLD, UNKNOWN}

    public final int x;
    public final int z;
    public final String dimension;

    public Status status = Status.UNKNOWN;
    public String statusReason = "";
    public boolean loaded;
    public boolean scanned;
    /** Set when fluid started flowing shortly after the chunk arrived (a sign of fresh generation). */
    public boolean flowedAfterLoad;
    public long loadedAt;

    // Block entity counters (read straight from the chunk's block entity map)
    public int chests;
    public int trappedChests;
    public int barrels;
    public int shulkers;
    public int enderChests;
    public int hoppers;
    public int dispensers;
    public int furnaces;
    public int beds;
    public int signs;
    public int beacons;
    public int enchantTables;
    public int brewingStands;
    public int crafters;

    // Section scan results
    public int artificial;
    public int fluidSources;
    public int fluidFlowing;
    public int fluidUnsettled;

    /** Position of a representative block (first storage / interesting block entity) for coordinates. */
    public int anchorX;
    public int anchorY;
    public int anchorZ;
    public boolean hasAnchor;

    public ChunkInfo(String dimension, int x, int z) {
        this.dimension = dimension;
        this.x = x;
        this.z = z;
        this.anchorX = x * 16 + 8;
        this.anchorZ = z * 16 + 8;
        this.anchorY = 64;
    }

    public int storage() {
        return chests + trappedChests + barrels + shulkers;
    }

    public int centerX() {
        return x * 16 + 8;
    }

    public int centerZ() {
        return z * 16 + 8;
    }

    public void resetBlockEntityCounts() {
        chests = trappedChests = barrels = shulkers = enderChests = hoppers = dispensers = furnaces = 0;
        beds = signs = beacons = enchantTables = brewingStands = crafters = 0;
        hasAnchor = false;
    }

    public static long key(int x, int z) {
        return ((long) x << 32) ^ (z & 0xFFFFFFFFL);
    }
}
