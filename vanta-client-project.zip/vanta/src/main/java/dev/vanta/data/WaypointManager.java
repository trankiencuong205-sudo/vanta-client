package dev.vanta.data;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import dev.vanta.VantaClient;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;

import java.io.Reader;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Waypoints saved to config/vanta/waypoints.json. They are stored per server (or "singleplayer"). */
public final class WaypointManager {
    private static final WaypointManager INSTANCE = new WaypointManager();

    public static WaypointManager get() {
        return INSTANCE;
    }

    public static final class Waypoint {
        public String name;
        public String server;
        public String dimension;
        public int x;
        public int y;
        public int z;
        public int color = 0xFF8B5CF6;
        public boolean visible = true;
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type LIST_TYPE = new TypeToken<List<Waypoint>>() {
    }.getType();

    private final List<Waypoint> all = new ArrayList<>();
    private final Path file = FabricLoader.getInstance().getConfigDir().resolve("vanta").resolve("waypoints.json");
    private boolean loaded;

    private WaypointManager() {
    }

    private void ensureLoaded() {
        if (loaded) return;
        loaded = true;
        if (!Files.exists(file)) return;
        try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            List<Waypoint> read = GSON.fromJson(r, LIST_TYPE);
            if (read != null) all.addAll(read);
        } catch (Throwable t) {
            VantaClient.LOGGER.warn("Could not read waypoints", t);
        }
    }

    public static String currentServer() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ServerInfo info = mc.getCurrentServerEntry();
        if (info != null && info.address != null) return info.address.toLowerCase();
        return "singleplayer";
    }

    public static String currentDimension() {
        return ChunkTracker.get().currentDimension();
    }

    /** Waypoints for the server and dimension the player is currently in. */
    public List<Waypoint> here() {
        ensureLoaded();
        String server = currentServer();
        String dim = currentDimension();
        List<Waypoint> out = new ArrayList<>();
        for (Waypoint w : all) {
            if (server.equals(w.server) && dim.equals(w.dimension)) out.add(w);
        }
        return out;
    }

    public List<Waypoint> everything() {
        ensureLoaded();
        return new ArrayList<>(all);
    }

    public Waypoint add(String name, int x, int y, int z, int color) {
        ensureLoaded();
        Waypoint w = new Waypoint();
        w.name = name;
        w.server = currentServer();
        w.dimension = currentDimension();
        w.x = x;
        w.y = y;
        w.z = z;
        w.color = color;
        all.add(w);
        save();
        return w;
    }

    public boolean remove(String name) {
        ensureLoaded();
        String server = currentServer();
        String dim = currentDimension();
        boolean removed = all.removeIf(w -> server.equals(w.server) && dim.equals(w.dimension)
                && w.name.equalsIgnoreCase(name));
        if (removed) save();
        return removed;
    }

    public void clearHere() {
        ensureLoaded();
        String server = currentServer();
        String dim = currentDimension();
        all.removeIf(w -> server.equals(w.server) && dim.equals(w.dimension));
        save();
    }

    public synchronized void save() {
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(file, GSON.toJson(all, LIST_TYPE), StandardCharsets.UTF_8);
        } catch (Throwable t) {
            VantaClient.LOGGER.warn("Could not save waypoints", t);
        }
    }
}
