package dev.vanta.mixin;

import dev.vanta.data.ChunkTracker;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ChunkDeltaUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Feeds fluid block updates to the chunk tracker (used by NewChunks). Both injections use require = 0 and run at
 * RETURN, which only happens on the client thread, so a version change can never crash the game.
 */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {
    @Inject(method = "onBlockUpdate", at = @At("RETURN"), require = 0)
    private void vanta$blockUpdate(BlockUpdateS2CPacket packet, CallbackInfo ci) {
        try {
            ChunkTracker.get().onFluidUpdate(packet.getPos(), packet.getState());
        } catch (Throwable ignored) {
        }
    }

    @Inject(method = "onChunkDeltaUpdate", at = @At("RETURN"), require = 0)
    private void vanta$deltaUpdate(ChunkDeltaUpdateS2CPacket packet, CallbackInfo ci) {
        try {
            packet.visitUpdates((pos, state) -> ChunkTracker.get().onFluidUpdate(pos, state));
        } catch (Throwable ignored) {
        }
    }
}
