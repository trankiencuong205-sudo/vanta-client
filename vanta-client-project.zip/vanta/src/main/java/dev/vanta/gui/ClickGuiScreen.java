package dev.vanta.gui;

import dev.vanta.VantaClient;
import dev.vanta.core.Category;
import dev.vanta.core.Module;
import dev.vanta.core.ModuleManager;
import dev.vanta.core.settings.ActionSetting;
import dev.vanta.core.settings.BoolSetting;
import dev.vanta.core.settings.ModeSetting;
import dev.vanta.core.settings.NumSetting;
import dev.vanta.core.settings.Setting;
import dev.vanta.core.settings.StringSetting;
import dev.vanta.util.Draw;
import dev.vanta.util.Keys;
import dev.vanta.util.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * The ClickGUI. It is drawn in immediate mode and reads the mouse and keyboard directly from GLFW
 * (see {@link Keys}), so it does not depend on Minecraft's input event signatures.
 *
 * Left click a module: toggle. Right click (or the arrow): show its settings. Click the key box: set a key bind
 * (Delete clears it). Right Shift closes the menu.
 */
public class ClickGuiScreen extends Screen {
    private static final int ROW_H = 30;
    private static final int SET_H = 22;
    private static final int SIDEBAR_W = 104;
    private static final int HEADER_H = 28;
    private static final int FOOTER_H = 18;

    private static Category lastCategory = Category.COMBAT;
    private static final Map<Module, Boolean> EXPANDED = new HashMap<>();

    private final Map<Module, Float> expandAnim = new HashMap<>();
    private final boolean[] prevKeys = new boolean[GLFW.GLFW_KEY_LAST + 1];

    private float openAnim;
    private float scroll;
    private float scrollTarget;
    private boolean prevL;
    private boolean prevR;

    private Module binding;
    private StringSetting editing;
    private NumSetting dragging;

    // per-frame state
    private boolean clickL;
    private boolean clickR;
    private boolean heldL;
    private int mx;
    private int my;
    private int cx1, cy1, cx2, cy2;
    private String hoverDesc = "";
    private float contentHeight;

    public ClickGuiScreen() {
        super(Text.literal("Vanta"));
        prevL = Keys.mouseDown(0);
        prevR = Keys.mouseDown(1);
        for (int k = 32; k < prevKeys.length; k++) prevKeys[k] = Keys.down(k);
    }

    // ------------------------------------------------------------------ Screen hooks

    public boolean shouldPause() {
        return false;
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        scrollTarget -= (float) vertical * 30f;
        return true;
    }

    public void removed() {
        dev.vanta.Config.save();
    }

    // ------------------------------------------------------------------ input polling

    private void pollKeys() {
        boolean shift = Keys.shift();
        for (int k = 32; k < prevKeys.length; k++) {
            boolean down = Keys.down(k);
            boolean edge = down && !prevKeys[k];
            prevKeys[k] = down;
            if (edge) onKey(k, shift);
        }
    }

    private void onKey(int key, boolean shift) {
        if (key == GLFW.GLFW_KEY_ESCAPE) return; // vanilla closes the screen on Escape

        if (binding != null) {
            if (key == VantaClient.GUI_KEY) return;
            if (key == GLFW.GLFW_KEY_DELETE || key == GLFW.GLFW_KEY_BACKSPACE) binding.setKey(-1);
            else binding.setKey(key);
            binding = null;
            VantaClient.requestSave();
            return;
        }
        if (editing != null) {
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
                editing = null;
            } else if (key == GLFW.GLFW_KEY_BACKSPACE) {
                String t = editing.get();
                if (!t.isEmpty()) editing.set(t.substring(0, t.length() - 1));
                VantaClient.requestSave();
            } else {
                char ch = Keys.typed(key, shift);
                if (ch != 0) {
                    editing.set(editing.get() + ch);
                    VantaClient.requestSave();
                }
            }
            return;
        }
        if (key == VantaClient.GUI_KEY) {
            VantaClient.suppressGuiKeyUntilReleased();
            MinecraftClient.getInstance().setScreen(null);
        }
    }

    // ------------------------------------------------------------------ rendering

    @Override
    public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        openAnim += (1f - openAnim) * 0.22f;
        mx = mouseX;
        my = mouseY;
        boolean l = Keys.mouseDown(0);
        boolean r = Keys.mouseDown(1);
        clickL = l && !prevL;
        clickR = r && !prevR;
        heldL = l;
        prevL = l;
        prevR = r;
        if (!heldL) dragging = null;
        hoverDesc = "";
        pollKeys();

        c.fill(0, 0, sw, sh, Theme.alpha(0xFF000000, (int) (140 * openAnim)));

        int w = Math.min(sw - 40, 620);
        int h = Math.min(sh - 40, 390);
        int x0 = (sw - w) / 2;
        int y0 = (sh - h) / 2 + (int) ((1f - openAnim) * 26);

        Draw.rounded(c, x0 - 1, y0 - 1, x0 + w + 1, y0 + h + 1, Theme.BORDER);
        Draw.rounded(c, x0, y0, x0 + w, y0 + h, Theme.BG);

        drawHeader(c, x0, y0, w);
        drawSidebar(c, x0, y0, h);

        cx1 = x0 + SIDEBAR_W + 8;
        cy1 = y0 + HEADER_H + 6;
        cx2 = x0 + w - 8;
        cy2 = y0 + h - FOOTER_H - 4;
        drawModules(c);
        drawFooter(c, x0, y0, w, h);

        if (clickL) {
            if (editing != null) editing = null;
            if (binding != null) binding = null;
        }
    }

    private void drawHeader(DrawContext c, int x0, int y0, int w) {
        c.fill(x0, y0, x0 + w, y0 + HEADER_H, Theme.PANEL);
        Draw.text(c, "VANTA", x0 + 12, y0 + 10, Theme.ACCENT);
        Draw.text(c, "client", x0 + 12 + Draw.textWidth("VANTA ") + 2, y0 + 10, Theme.TEXT_DIM);
        String hint = "Right Shift to close";
        Draw.text(c, hint, x0 + w - 12 - Draw.textWidth(hint), y0 + 10, Theme.TEXT_DIM);
        int slices = 32;
        for (int i = 0; i < slices; i++) {
            int a = x0 + (w * i) / slices;
            int b = x0 + (w * (i + 1)) / slices;
            c.fill(a, y0 + HEADER_H - 1, b, y0 + HEADER_H, Theme.lerp(Theme.ACCENT, Theme.ACCENT_2, i / (float) (slices - 1)));
        }
    }

    private void drawSidebar(DrawContext c, int x0, int y0, int h) {
        int top = y0 + HEADER_H;
        c.fill(x0, top, x0 + SIDEBAR_W, y0 + h, Theme.PANEL_ALT);
        int y = top + 8;
        for (Category cat : Category.values()) {
            int x1 = x0 + 6, x2 = x0 + SIDEBAR_W - 6;
            boolean selected = cat == lastCategory;
            boolean hover = mx >= x1 && mx < x2 && my >= y && my < y + 24;
            if (selected) {
                Draw.rounded(c, x1, y, x2, y + 24, Theme.ROW);
                c.fill(x1, y + 4, x1 + 2, y + 20, Theme.ACCENT);
            } else if (hover) {
                Draw.rounded(c, x1, y, x2, y + 24, Theme.ROW_HOVER);
            }
            Draw.text(c, cat.label, x1 + 10, y + 8, selected ? Theme.TEXT : Theme.TEXT_DIM);
            int on = 0, total = 0;
            for (Module m : ModuleManager.get().inCategory(cat)) {
                total++;
                if (m.isEnabled()) on++;
            }
            String count = on + "/" + total;
            Draw.text(c, count, x2 - 6 - Draw.textWidth(count), y + 8, on > 0 ? Theme.ACCENT : Theme.TEXT_DIM);
            if (hover) hoverDesc = total + " modules in " + cat.label;
            if (hover && clickL) {
                lastCategory = cat;
                scroll = 0;
                scrollTarget = 0;
                clickL = false;
            }
            y += 28;
        }
    }

    private void drawFooter(DrawContext c, int x0, int y0, int w, int h) {
        int y = y0 + h - FOOTER_H;
        c.fill(x0 + SIDEBAR_W, y, x0 + w, y0 + h, Theme.PANEL);
        String text = !hoverDesc.isEmpty() ? hoverDesc : "Left click: toggle   Right click: settings   Key box: bind (Delete clears)";
        Draw.text(c, text, x0 + SIDEBAR_W + 10, y + 5, hoverDesc.isEmpty() ? Theme.TEXT_DIM : Theme.TEXT);
    }

    private void drawModules(DrawContext c) {
        List<Module> list = ModuleManager.get().inCategory(lastCategory);
        float maxScroll = Math.max(0f, contentHeight - (cy2 - cy1));
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget));
        scroll += (scrollTarget - scroll) * 0.3f;

        c.enableScissor(cx1, cy1, cx2, cy2);
        int y = cy1 - Math.round(scroll);
        int start = y;
        for (Module m : list) {
            y += drawModule(c, m, cx1, y, cx2 - 4);
        }
        contentHeight = y - start;
        c.disableScissor();

        // scroll bar
        if (maxScroll > 0) {
            int trackH = cy2 - cy1;
            int barH = Math.max(18, (int) (trackH * (trackH / contentHeight)));
            int barY = cy1 + (int) ((trackH - barH) * (scroll / maxScroll));
            c.fill(cx2 - 2, barY, cx2, barY + barH, Theme.alpha(Theme.ACCENT, 160));
        }
    }

    private boolean inContent() {
        return mx >= cx1 && mx < cx2 && my >= cy1 && my < cy2;
    }

    private static boolean in(int mx, int my, int x1, int y1, int x2, int y2) {
        return mx >= x1 && mx < x2 && my >= y1 && my < y2;
    }

    private int drawModule(DrawContext c, Module m, int x1, int y, int x2) {
        boolean expanded = EXPANDED.getOrDefault(m, false);
        float target = expanded ? 1f : 0f;
        float ea = expandAnim.getOrDefault(m, 0f);
        ea += (target - ea) * 0.28f;
        if (Math.abs(ea - target) < 0.01f) ea = target;
        expandAnim.put(m, ea);

        List<Setting<?>> visible = new ArrayList<>();
        for (Setting<?> s : m.settings) if (s.isVisible()) visible.add(s);
        int settingsH = visible.isEmpty() ? 0 : visible.size() * SET_H + 6;
        int extra = Math.round(settingsH * ea);
        int total = ROW_H + extra;

        boolean hoverRow = inContent() && in(mx, my, x1, y, x2, y + ROW_H);
        Draw.rounded(c, x1, y, x2, y + total, hoverRow ? Theme.ROW_HOVER : Theme.ROW);

        m.anim += ((m.isEnabled() ? 1f : 0f) - m.anim) * 0.25f;
        if (Math.abs(m.anim - (m.isEnabled() ? 1f : 0f)) < 0.01f) m.anim = m.isEnabled() ? 1f : 0f;
        c.fill(x1, y + 5, x1 + 2, y + ROW_H - 5, Theme.lerp(Theme.BORDER, Theme.ACCENT, m.anim));

        Draw.text(c, m.name, x1 + 10, y + 6, Theme.lerp(Theme.TEXT_DIM, Theme.TEXT, m.anim));

        // controls on the right
        int arrowX1 = x2 - 22, arrowX2 = x2 - 6;
        int swX2 = x2 - 28, swX1 = swX2 - 30;
        String keyText = binding == m ? "..." : Keys.name(m.getKey());
        int chipW = Math.max(40, Draw.textWidth(keyText) + 12);
        int chipX2 = swX1 - 8, chipX1 = chipX2 - chipW;

        // description (cut to the free space)
        int descMax = chipX1 - (x1 + 10) - 8;
        Draw.text(c, fit(m.description, descMax), x1 + 10, y + 17, Theme.TEXT_DIM);

        // key chip
        boolean hoverChip = inContent() && in(mx, my, chipX1, y + 7, chipX2, y + 23);
        Draw.rounded(c, chipX1, y + 7, chipX2, y + 23, hoverChip ? Theme.BORDER : Theme.PANEL);
        Draw.textCentered(c, keyText, (chipX1 + chipX2) / 2, y + 11, binding == m ? Theme.ACCENT : Theme.TEXT_DIM);

        // switch
        drawSwitch(c, swX1, y + 9, m.anim);

        // arrow
        boolean hoverArrow = inContent() && in(mx, my, arrowX1, y + 7, arrowX2, y + 23);
        String arrow = expanded ? "^" : "v";
        if (!visible.isEmpty()) {
            Draw.textCentered(c, arrow, (arrowX1 + arrowX2) / 2, y + 11, hoverArrow ? Theme.TEXT : Theme.TEXT_DIM);
        }

        if (hoverRow) hoverDesc = m.description;

        if (inContent() && (clickL || clickR)) {
            if (hoverChip) {
                if (clickL) {
                    binding = m;
                    editing = null;
                } else {
                    m.setKey(-1);
                    VantaClient.requestSave();
                }
                clickL = clickR = false;
            } else if (hoverArrow && !visible.isEmpty()) {
                if (clickL) EXPANDED.put(m, !expanded);
                clickL = clickR = false;
            } else if (hoverRow) {
                if (clickL) {
                    m.toggle();
                } else if (!visible.isEmpty()) {
                    EXPANDED.put(m, !expanded);
                }
                clickL = clickR = false;
            }
        }

        // settings
        if (ea > 0.02f && !visible.isEmpty()) {
            int clipTop = Math.max(y + ROW_H, cy1);
            int clipBottom = Math.min(y + total, cy2);
            if (clipBottom > clipTop) {
                c.enableScissor(x1, clipTop, x2, clipBottom);
                int sy = y + ROW_H + 3;
                boolean interactive = ea > 0.97f;
                for (Setting<?> s : visible) {
                    drawSetting(c, s, x1 + 10, sy, x2 - 10, interactive);
                    sy += SET_H;
                }
                c.disableScissor();
            }
        }
        return total + 4;
    }

    private void drawSwitch(DrawContext c, int x, int y, float anim) {
        int w = 30, h = 12;
        Draw.rounded(c, x, y, x + w, y + h, Theme.lerp(Theme.BORDER, Theme.ACCENT, anim));
        int knobX = x + 2 + Math.round(anim * (w - 4 - 8));
        Draw.rounded(c, knobX, y + 2, knobX + 8, y + h - 2, Theme.TEXT);
    }

    private void drawSetting(DrawContext c, Setting<?> s, int x1, int y, int x2, boolean interactive) {
        boolean hover = interactive && inContent() && in(mx, my, x1, y, x2, y + SET_H);
        if (hover) hoverDesc = s.name + ": " + s.description;

        if (s instanceof BoolSetting b) {
            Draw.text(c, b.name, x1, y + 7, Theme.TEXT);
            int x = x2 - 30;
            drawSwitch(c, x, y + 5, b.on() ? 1f : 0f);
            if (hover && clickL) {
                b.toggle();
                VantaClient.requestSave();
                clickL = false;
            }
        } else if (s instanceof NumSetting n) {
            String value = format(n);
            Draw.text(c, n.name, x1, y + 2, Theme.TEXT);
            Draw.text(c, value, x2 - Draw.textWidth(value), y + 2, Theme.TEXT_DIM);
            int by1 = y + 14, by2 = y + 18;
            Draw.rounded(c, x1, by1, x2, by2, Theme.PANEL);
            double t = (n.num() - n.min) / (n.max - n.min);
            int fillX = x1 + (int) Math.round((x2 - x1) * Math.max(0, Math.min(1, t)));
            if (fillX > x1) Draw.rounded(c, x1, by1, fillX, by2, Theme.ACCENT);
            Draw.rounded(c, fillX - 2, by1 - 2, fillX + 2, by2 + 2, Theme.TEXT);
            boolean hoverBar = interactive && inContent() && in(mx, my, x1 - 2, y + 10, x2 + 2, y + SET_H);
            if (hoverBar && clickL) {
                dragging = n;
                clickL = false;
            }
            if (dragging == n && heldL) {
                double v = Math.max(0, Math.min(1, (mx - x1) / (double) (x2 - x1)));
                n.set(n.min + v * (n.max - n.min));
                VantaClient.requestSave();
            }
        } else if (s instanceof ModeSetting mode) {
            Draw.text(c, mode.name, x1, y + 7, Theme.TEXT);
            int cw = Draw.textWidth(mode.get()) + 14;
            int cx = x2 - cw;
            Draw.rounded(c, cx, y + 3, x2, y + SET_H - 3, hover ? Theme.BORDER : Theme.PANEL);
            Draw.textCentered(c, mode.get(), cx + cw / 2, y + 7, Theme.ACCENT);
            if (hover && (clickL || clickR)) {
                mode.cycle(clickL);
                VantaClient.requestSave();
                clickL = clickR = false;
            }
        } else if (s instanceof StringSetting str) {
            Draw.text(c, str.name, x1, y + 7, Theme.TEXT);
            int bx1 = x1 + 70;
            boolean active = editing == str;
            Draw.rounded(c, bx1, y + 3, x2, y + SET_H - 3, active ? Theme.BORDER : Theme.PANEL);
            String text = str.get();
            String shown = tail(text, x2 - bx1 - 10);
            boolean caret = active && (System.currentTimeMillis() / 450) % 2 == 0;
            Draw.text(c, shown + (caret ? "_" : ""), bx1 + 5, y + 7, active ? Theme.TEXT : Theme.TEXT_DIM);
            if (hover && clickL && in(mx, my, bx1, y + 3, x2, y + SET_H - 3)) {
                editing = str;
                binding = null;
                clickL = false;
            }
        } else if (s instanceof ActionSetting action) {
            Draw.rounded(c, x1, y + 2, x2, y + SET_H - 2, hover ? Theme.ACCENT : Theme.PANEL);
            Draw.textCentered(c, action.name, (x1 + x2) / 2, y + 7, Theme.TEXT);
            if (hover && clickL) {
                action.run();
                clickL = false;
            }
        }
    }

    // ------------------------------------------------------------------ text helpers

    private static String format(NumSetting n) {
        double v = n.num();
        if (n.step >= 1 && Math.abs(v - Math.rint(v)) < 1e-9) return String.valueOf((long) Math.rint(v));
        return String.format(Locale.ROOT, n.step < 0.1 ? "%.2f" : "%.1f", v);
    }

    private static String fit(String s, int maxWidth) {
        if (maxWidth <= 0) return "";
        if (Draw.textWidth(s) <= maxWidth) return s;
        while (s.length() > 1 && Draw.textWidth(s + "...") > maxWidth) s = s.substring(0, s.length() - 1);
        return s + "...";
    }

    /** Keeps the end of the text visible (where the caret is) when it is wider than the box. */
    private static String tail(String s, int maxWidth) {
        while (s.length() > 1 && Draw.textWidth(s) > maxWidth) s = s.substring(1);
        return s;
    }
}
