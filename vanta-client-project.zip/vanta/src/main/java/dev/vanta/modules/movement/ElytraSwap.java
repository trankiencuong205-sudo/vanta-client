package dev.vanta.modules.movement;

import dev.vanta.core.Category;
import dev.vanta.core.Module;
import dev.vanta.util.Notifier;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;

/** One-shot module: enable it (or press its key) to swap between your chestplate and your elytra. */
public class ElytraSwap extends Module {
    public ElytraSwap() {
        super("ElytraSwap", "Swaps your chestplate and elytra in one press (works from the inventory, no hotbar needed).", Category.MOVEMENT);
    }

    @Override
    protected void onTick() {
        try {
            swap();
        } finally {
            setEnabled(false, false);
        }
    }

    private static String idOf(ItemStack s) {
        return s.isEmpty() ? "" : Registries.ITEM.getId(s.getItem()).getPath();
    }

    private void swap() {
        if (mc.player == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null) {
            Notifier.warn("Close the open screen first");
            return;
        }
        String worn = idOf(mc.player.getEquippedStack(EquipmentSlot.CHEST));
        boolean wearingElytra = worn.equals("elytra");
        int slot = -1;
        for (int i = 0; i < 36; i++) {
            String id = idOf(mc.player.getInventory().getStack(i));
            boolean match = wearingElytra ? id.endsWith("_chestplate") : id.equals("elytra");
            if (match) {
                slot = i;
                break;
            }
        }
        if (slot < 0) {
            Notifier.warn(wearingElytra ? "No chestplate in your inventory" : "No elytra in your inventory");
            return;
        }
        // Inventory index -> player screen slot id (hotbar 0-8 becomes 36-44, main 9-35 stays).
        int from = slot < 9 ? slot + 36 : slot;
        int chestSlot = 6;
        int syncId = mc.player.playerScreenHandler.syncId;
        mc.interactionManager.clickSlot(syncId, from, 0, SlotActionType.PICKUP, mc.player);
        mc.interactionManager.clickSlot(syncId, chestSlot, 0, SlotActionType.PICKUP, mc.player);
        mc.interactionManager.clickSlot(syncId, from, 0, SlotActionType.PICKUP, mc.player);
        Notifier.good(wearingElytra ? "Chestplate equipped" : "Elytra equipped");
    }
}
