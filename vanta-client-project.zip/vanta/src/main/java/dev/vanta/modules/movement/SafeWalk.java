package dev.vanta.modules.movement;

import dev.vanta.core.Category;
import dev.vanta.core.Module;
import dev.vanta.core.settings.NumSetting;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class SafeWalk extends Module {
    private final NumSetting lookAhead = add(new NumSetting("Look ahead", "Ticks of movement checked in advance", 4, 1, 8, 1));

    private boolean sneakingByUs;

    public SafeWalk() {
        super("SafeWalk", "Sneaks automatically at the edge of a drop so you cannot walk off by accident.", Category.MOVEMENT);
    }

    @Override
    protected void onDisable() {
        release();
    }

    private void release() {
        if (sneakingByUs) mc.options.sneakKey.setPressed(false);
        sneakingByUs = false;
    }

    @Override
    protected void onTick() {
        if (mc.player == null || mc.world == null) return;
        if (mc.currentScreen != null) {
            release();
            return;
        }
        boolean danger = false;
        if (mc.player.isOnGround() && !mc.player.isTouchingWater() && !mc.player.isClimbing()) {
            Vec3d v = mc.player.getVelocity();
            double ahead = lookAhead.num();
            double hx = v.x * ahead, hz = v.z * ahead;
            if (Math.abs(hx) + Math.abs(hz) > 0.01) {
                double px = mc.player.getX() + hx, py = mc.player.getY(), pz = mc.player.getZ() + hz;
                Box probe = new Box(px - 0.1, py - 0.7, pz - 0.1, px + 0.1, py - 0.01, pz + 0.1);
                danger = !mc.world.getBlockCollisions(mc.player, probe).iterator().hasNext();
            }
        }
        if (danger) {
            mc.options.sneakKey.setPressed(true);
            sneakingByUs = true;
        } else {
            release();
        }
    }
}
