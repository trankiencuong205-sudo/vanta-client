package dev.vanta.modules.render;

import dev.vanta.core.Category;
import dev.vanta.core.Module;
import dev.vanta.core.settings.BoolSetting;
import dev.vanta.core.settings.ModeSetting;
import dev.vanta.core.settings.NumSetting;
import dev.vanta.util.Draw;
import dev.vanta.util.Projection;
import dev.vanta.util.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class Esp extends Module {
    private final BoolSetting players = add(new BoolSetting("Players", "Highlight other players", true));
    private final BoolSetting hostiles = add(new BoolSetting("Hostiles", "Highlight hostile mobs", true));
    private final BoolSetting passives = add(new BoolSetting("Passives", "Highlight animals and villagers", false));
    private final BoolSetting items = add(new BoolSetting("Items", "Highlight dropped items", true));
    private final ModeSetting style = add(new ModeSetting("Style", "2D rectangle or full 3D wireframe", "Box", "Box", "Box3D"));
    private final BoolSetting fill = add(new BoolSetting("Fill", "Translucent fill inside the box", false));
    private final BoolSetting tracers = add(new BoolSetting("Tracers", "Line from the bottom of the screen to each target", false));
    private final BoolSetting names = add(new BoolSetting("Names", "Name and distance above the box", true));
    private final BoolSetting health = add(new BoolSetting("Health bar", "Health bar next to living targets", true));
    private final NumSetting range = add(new NumSetting("Range", "Maximum distance in blocks", 96, 16, 256, 8));
    private final NumSetting limit = add(new NumSetting("Max targets", "Upper limit of drawn targets per frame", 120, 10, 300, 10));

    private int count;

    public Esp() {
        super("ESP", "Draws boxes, names and health through walls around players, mobs and items.", Category.RENDER);
    }

    @Override
    public String getInfo() {
        return count > 0 ? String.valueOf(count) : "";
    }

    @Override
    protected void onHud(DrawContext c) {
        if (!Projection.isReady()) return;
        count = 0;
        float pt = (float) Projection.partialTick();
        double maxDist = range.num();
        int maxDrawn = limit.intValue();
        int sw = Projection.width();
        int sh = Projection.height();
        boolean box3d = style.is("Box3D");

        for (Entity e : mc.world.getEntities()) {
            if (count >= maxDrawn) break;
            if (e == mc.player || e.isRemoved()) continue;
            int color = colorFor(e);
            if (color == 0) continue;
            if (mc.player.distanceTo(e) > maxDist) continue;

            Vec3d lerped = e.getLerpedPos(pt);
            Box box = e.getBoundingBox().offset(lerped.x - e.getX(), lerped.y - e.getY(), lerped.z - e.getZ());
            int fillColor = fill.on() ? Theme.alpha(color, 45) : 0;

            double[] bounds;
            if (box3d) {
                bounds = Draw.bounds(box);
                if (bounds == null) continue;
                if (fill.on()) {
                    Draw.rect(c, (int) bounds[0], (int) bounds[1], (int) bounds[2], (int) bounds[3], fillColor);
                }
                Draw.box3d(c, box, color);
            } else {
                bounds = Draw.box2d(c, box, color, fillColor);
                if (bounds == null) continue;
            }
            count++;

            double cx = (bounds[0] + bounds[2]) / 2.0;
            if (tracers.on()) {
                Draw.line(c, sw / 2.0, sh, cx, bounds[3], Theme.alpha(color, 200), 1);
            }
            if (names.on()) {
                String label = labelFor(e);
                Draw.textCentered(c, label, (int) cx, (int) bounds[1] - 10, Theme.TEXT);
            }
            if (health.on() && e instanceof LivingEntity living && !(e instanceof ItemEntity)) {
                float max = Math.max(1f, living.getMaxHealth());
                float ratio = Math.max(0f, Math.min(1f, living.getHealth() / max));
                int bx = (int) bounds[0] - 4;
                int top = (int) bounds[1];
                int bottom = (int) bounds[3];
                c.fill(bx, top, bx + 2, bottom, Theme.alpha(0xFF000000, 160));
                int h = (int) ((bottom - top) * ratio);
                int hc = Theme.lerp(Theme.BAD, Theme.OK, ratio);
                c.fill(bx, bottom - h, bx + 2, bottom, hc);
            }
        }
    }

    private int colorFor(Entity e) {
        if (e instanceof PlayerEntity) return players.on() ? Theme.ACCENT_2 : 0;
        if (e instanceof ItemEntity) return items.on() ? Theme.WARN : 0;
        if (e instanceof Monster) return hostiles.on() ? Theme.BAD : 0;
        if (e instanceof PassiveEntity) return passives.on() ? Theme.OK : 0;
        return 0;
    }

    private String labelFor(Entity e) {
        String text;
        if (e instanceof ItemEntity item) {
            text = item.getStack().getName().getString();
            int n = item.getStack().getCount();
            if (n > 1) text += " x" + n;
        } else {
            text = e.getName().getString();
        }
        return text + " " + Math.round(mc.player.distanceTo(e)) + "m";
    }
}
