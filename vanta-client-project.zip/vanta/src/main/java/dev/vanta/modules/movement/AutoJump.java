package dev.vanta.modules.movement;

import dev.vanta.core.Category;
import dev.vanta.core.Module;

public class AutoJump extends Module {
    private boolean pressedByUs;

    public AutoJump() {
        super("AutoJump", "Jumps by itself when you walk into a block (like the vanilla Auto-Jump option, but always on).", Category.MOVEMENT);
    }

    @Override
    protected void onDisable() {
        if (pressedByUs) mc.options.jumpKey.setPressed(false);
        pressedByUs = false;
    }

    @Override
    protected void onTick() {
        if (mc.player == null) return;
        if (pressedByUs) {
            mc.options.jumpKey.setPressed(false);
            pressedByUs = false;
            return;
        }
        if (mc.currentScreen != null || mc.player.isSneaking()) return;
        boolean moving = mc.options.forwardKey.isPressed() || mc.options.backKey.isPressed()
                || mc.options.leftKey.isPressed() || mc.options.rightKey.isPressed();
        if (moving && mc.player.isOnGround() && mc.player.horizontalCollision) {
            mc.options.jumpKey.setPressed(true);
            pressedByUs = true;
        }
    }
}
