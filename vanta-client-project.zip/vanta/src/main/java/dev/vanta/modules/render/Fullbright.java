package dev.vanta.modules.render;

import dev.vanta.core.Category;
import dev.vanta.core.Module;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

public class Fullbright extends Module {
    private static final int DURATION = 1_000_000;
    private boolean applied;

    public Fullbright() {
        super("Fullbright", "Maximum brightness everywhere (client-side night vision, no server effect).", Category.RENDER);
    }

    @Override
    protected void onDisable() {
        remove();
    }

    @Override
    protected void onTick() {
        if (mc.player == null) return;
        StatusEffectInstance current = mc.player.getStatusEffect(StatusEffects.NIGHT_VISION);
        if (current == null || (applied && current.getDuration() < 20_000)) {
            mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, DURATION, 0, false, false, false));
            applied = true;
        }
    }

    private void remove() {
        if (applied && mc.player != null) {
            mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
        applied = false;
    }
}
