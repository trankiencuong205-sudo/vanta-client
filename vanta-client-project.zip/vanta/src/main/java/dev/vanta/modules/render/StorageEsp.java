package dev.vanta.modules.render;

import dev.vanta.core.Category;
import dev.vanta.core.Module;
import dev.vanta.core.settings.BoolSetting;
import dev.vanta.core.settings.NumSetting;
import dev.vanta.util.Draw;
import dev.vanta.util.Projection;
import dev.vanta.util.Theme;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.List;

public class StorageEsp extends Module {
    private final BoolSetting chests = add(new BoolSetting("Chests", "Chests and trapped chests", true));
    private final BoolSetting barrels = add(new BoolSetting("Barrels", "Barrels", true));
    private final BoolSetting shulkers = add(new BoolSetting("Shulkers", "Shulker boxes", true));
    private final BoolSetting enderChests = add(new BoolSetting("Ender chests", "Ender chests", true));
    private final BoolSetting hoppers = add(new BoolSetting("Hoppers", "Hoppers, droppers and dispensers", false));
    private final BoolSetting furnaces = add(new BoolSetting("Furnaces", "Furnaces, smokers and blast furnaces", false));
    private final BoolSetting fill = add(new BoolSetting("Fill", "Translucent fill inside the box", true));
    private final BoolSetting tracers = add(new BoolSetting("Tracers", "Line from the bottom of the screen", false));
    private final NumSetting range = add(new NumSetting("Range", "Maximum distance in blocks", 96, 16, 256, 8));

    private static final class Entry {
        final BlockPos pos;
        final int color;
        final String label;

        Entry(BlockPos pos, int color, String label) {
            this.pos = pos;
            this.color = color;
            this.label = label;
        }
    }

    private List<Entry> entries = new ArrayList<>();
    private int tickCounter;
    private int shown;

    public StorageEsp() {
        super("StorageESP", "Highlights chests, barrels, shulker boxes and other containers through walls.", Category.RENDER);
    }

    @Override
    public String getInfo() {
        return shown > 0 ? String.valueOf(shown) : "";
    }

    @Override
    protected void onEnable() {
        tickCounter = 0;
        rebuild();
    }

    @Override
    protected void onDisable() {
        entries = new ArrayList<>();
    }

    @Override
    protected void onTick() {
        if (tickCounter++ % 10 == 0) rebuild();
    }

    private void rebuild() {
        if (mc.world == null || mc.player == null) return;
        List<Entry> out = new ArrayList<>();
        int radiusChunks = (int) Math.ceil(range.num() / 16.0) + 1;
        int pcx = mc.player.getBlockPos().getX() >> 4;
        int pcz = mc.player.getBlockPos().getZ() >> 4;
        double maxSq = range.num() * range.num();
        double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();

        for (int dx = -radiusChunks; dx <= radiusChunks; dx++) {
            for (int dz = -radiusChunks; dz <= radiusChunks; dz++) {
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(pcx + dx, pcz + dz);
                if (chunk == null) continue;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    BlockPos p = be.getPos();
                    double ddx = p.getX() + 0.5 - px, ddy = p.getY() + 0.5 - py, ddz = p.getZ() + 0.5 - pz;
                    if (ddx * ddx + ddy * ddy + ddz * ddz > maxSq) continue;
                    String id = Registries.BLOCK_ENTITY_TYPE.getId(be.getType()).getPath();
                    Entry e = classify(id, p);
                    if (e != null) out.add(e);
                    if (out.size() >= 600) break;
                }
            }
        }
        entries = out;
    }

    private Entry classify(String id, BlockPos p) {
        switch (id) {
            case "chest":
            case "copper_chest":
                return chests.on() ? new Entry(p, 0xFFF59E0B, "Chest") : null;
            case "trapped_chest":
                return chests.on() ? new Entry(p, 0xFFEF4444, "Trapped chest") : null;
            case "barrel":
                return barrels.on() ? new Entry(p, 0xFFB45309, "Barrel") : null;
            case "shulker_box":
                return shulkers.on() ? new Entry(p, 0xFFA855F6, "Shulker") : null;
            case "ender_chest":
                return enderChests.on() ? new Entry(p, 0xFFD946EF, "Ender chest") : null;
            case "hopper":
                return hoppers.on() ? new Entry(p, 0xFF9CA3AF, "Hopper") : null;
            case "dropper":
            case "dispenser":
                return hoppers.on() ? new Entry(p, 0xFF9CA3AF, "Dispenser") : null;
            case "furnace":
            case "blast_furnace":
            case "smoker":
                return furnaces.on() ? new Entry(p, 0xFFFB923C, "Furnace") : null;
            default:
                return null;
        }
    }

    @Override
    protected void onHud(DrawContext c) {
        if (!Projection.isReady()) return;
        shown = 0;
        int sw = Projection.width();
        int sh = Projection.height();
        for (Entry e : entries) {
            Box box = new Box(e.pos);
            int fillColor = fill.on() ? Theme.alpha(e.color, 50) : 0;
            double[] bounds = Draw.box2d(c, box, e.color, fillColor);
            if (bounds == null) continue;
            shown++;
            if (tracers.on()) {
                Draw.line(c, sw / 2.0, sh, (bounds[0] + bounds[2]) / 2.0, bounds[3], Theme.alpha(e.color, 190), 1);
            }
        }
    }
}
