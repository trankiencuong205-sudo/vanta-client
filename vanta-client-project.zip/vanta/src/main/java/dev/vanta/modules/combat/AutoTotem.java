package dev.vanta.modules.combat;

import dev.vanta.core.Category;
import dev.vanta.core.Module;
import dev.vanta.core.settings.NumSetting;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;

public class AutoTotem extends Module {
    private final NumSetting delay = add(new NumSetting("Delay", "Ticks to wait between swaps", 3, 0, 20, 1));
    private final NumSetting healthLimit = add(new NumSetting("Health limit", "Only equip when health is at or below this (0 = always)", 0, 0, 20, 1));

    private int cooldown;
    private int totems;

    public AutoTotem() {
        super("AutoTotem", "Keeps a Totem of Undying in your off hand by taking one from your inventory.", Category.COMBAT);
    }

    @Override
    public String getInfo() {
        return String.valueOf(totems);
    }

    private static boolean isTotem(ItemStack s) {
        return !s.isEmpty() && Registries.ITEM.getId(s.getItem()).getPath().equals("totem_of_undying");
    }

    @Override
    protected void onTick() {
        if (mc.player == null || mc.interactionManager == null) return;

        int count = 0;
        int first = -1;
        for (int i = 0; i < 36; i++) {
            if (isTotem(mc.player.getInventory().getStack(i))) {
                count++;
                if (first < 0) first = i;
            }
        }
        boolean inOffhand = isTotem(mc.player.getOffHandStack());
        totems = count + (inOffhand ? 1 : 0);

        if (cooldown > 0) {
            cooldown--;
            return;
        }
        if (inOffhand || first < 0 || mc.currentScreen != null) return;
        if (healthLimit.intValue() > 0 && mc.player.getHealth() > healthLimit.intValue()) return;

        int slotId = first < 9 ? first + 36 : first;
        // Button 40 on a SWAP click exchanges the clicked slot with the off hand.
        mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, slotId, 40, SlotActionType.SWAP, mc.player);
        cooldown = delay.intValue();
    }
}
