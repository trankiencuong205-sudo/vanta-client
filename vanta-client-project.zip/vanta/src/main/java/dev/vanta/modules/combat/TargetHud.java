package dev.vanta.modules.combat;

import dev.vanta.core.Category;
import dev.vanta.core.Module;
import dev.vanta.core.settings.NumSetting;
import dev.vanta.util.Draw;
import dev.vanta.util.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

public class TargetHud extends Module {
    private final NumSetting hold = add(new NumSetting("Hold time", "Seconds the panel stays after you stop looking at a target", 3, 1, 10, 1));
    private final NumSetting range = add(new NumSetting("Nearby range", "Show the closest player within this range when nothing is targeted (0 = off)", 8, 0, 32, 1));

    private LivingEntity target;
    private long lastSeen;
    private float shownHealth;

    public TargetHud() {
        super("TargetHUD", "Shows name, health, armor and distance of the entity you look at.", Category.COMBAT);
    }

    @Override
    protected void onTick() {
        if (mc.player == null || mc.world == null) return;
        Entity looked = mc.targetedEntity;
        if (looked instanceof LivingEntity living && living.isAlive()) {
            target = living;
            lastSeen = System.currentTimeMillis();
            return;
        }
        if (range.num() > 0 && (target == null || System.currentTimeMillis() - lastSeen > hold.num() * 1000)) {
            PlayerEntity best = null;
            double bestDist = range.num();
            for (PlayerEntity p : mc.world.getPlayers()) {
                if (p == mc.player) continue;
                double d = mc.player.distanceTo(p);
                if (d < bestDist) {
                    bestDist = d;
                    best = p;
                }
            }
            if (best != null) {
                target = best;
                lastSeen = System.currentTimeMillis();
            }
        }
    }

    @Override
    protected void onHud(DrawContext c) {
        if (target == null) return;
        if (!target.isAlive() || System.currentTimeMillis() - lastSeen > hold.num() * 1000) {
            target = null;
            return;
        }
        float max = Math.max(1f, target.getMaxHealth());
        float hp = Math.max(0f, target.getHealth());
        shownHealth += (hp - shownHealth) * 0.2f;
        float ratio = Math.max(0f, Math.min(1f, shownHealth / max));

        int w = 150, h = 44;
        int x = mc.getWindow().getScaledWidth() / 2 + 24;
        int y = mc.getWindow().getScaledHeight() / 2 + 24;
        c.fill(x, y, x + w, y + h, Theme.mul(Theme.PANEL, 0.92f));
        c.fill(x, y, x + 2, y + h, Theme.pulse(2.0));
        Draw.text(c, target.getName().getString(), x + 8, y + 5, Theme.TEXT);
        String hpText = String.format("%.1f / %.0f", hp, max);
        Draw.text(c, hpText, x + w - 6 - Draw.textWidth(hpText), y + 5, Theme.TEXT_DIM);

        c.fill(x + 8, y + 18, x + w - 8, y + 24, Theme.ROW);
        c.fill(x + 8, y + 18, x + 8 + (int) ((w - 16) * ratio), y + 24, Theme.lerp(Theme.BAD, Theme.OK, ratio));

        String info = "Armor " + target.getArmor() + "   " + Math.round(mc.player.distanceTo(target)) + "m";
        Draw.text(c, info, x + 8, y + 29, Theme.TEXT_DIM);
    }
}
