package dev.vanta.modules.world;

import dev.vanta.core.Category;
import dev.vanta.core.Module;
import dev.vanta.core.settings.ActionSetting;
import dev.vanta.core.settings.BoolSetting;
import dev.vanta.core.settings.NumSetting;
import dev.vanta.data.ChunkInfo;
import dev.vanta.data.ChunkTracker;
import dev.vanta.util.ChunkMap;
import dev.vanta.util.ChunkOutline;
import dev.vanta.util.Notifier;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public class NewChunks extends Module {
    private static final int NEW_COLOR = 0xFFEF4444;
    private static final int OLD_COLOR = 0xFF166534;

    private final BoolSetting map = add(new BoolSetting("Map", "Top-down chunk map in the bottom-left corner", true));
    private final BoolSetting outline = add(new BoolSetting("Outline", "Outline new chunks on the ground around you", true));
    private final BoolSetting showOld = add(new BoolSetting("Show old chunks", "Also colour chunks that were already generated", true));
    private final NumSetting radius = add(new NumSetting("Map radius", "Chunks shown around you on the map", 10, 4, 20, 1));
    private final NumSetting cell = add(new NumSetting("Cell size", "Pixels per chunk on the map", 4, 2, 8, 1));
    private final NumSetting outlineRange = add(new NumSetting("Outline range", "Chunks around you that get outlines", 4, 1, 8, 1));

    private int newCount;
    private int oldCount;
    private int tick;
    private List<ChunkInfo> newNearby = new ArrayList<>();

    public NewChunks() {
        super("NewChunks", "Marks chunks the server generated just now (new) versus chunks that already existed (old).", Category.WORLD);
        add(new ActionSetting("Reset data", "Forget everything learned in this dimension", () -> {
            ChunkTracker.get().clearCurrentDimension();
            Notifier.info("NewChunks data cleared");
        }));
    }

    @Override
    public String getInfo() {
        return newCount + "/" + (newCount + oldCount);
    }

    @Override
    protected void onEnable() {
        ChunkTracker.get().acquire(this);
        tick = 0;
    }

    @Override
    protected void onDisable() {
        ChunkTracker.get().release(this);
        newNearby = new ArrayList<>();
        newCount = 0;
        oldCount = 0;
    }

    @Override
    protected void onTick() {
        if (tick++ % 20 != 0) return;
        int n = 0, o = 0;
        List<ChunkInfo> nearby = new ArrayList<>();
        int pcx = mc.player.getBlockPos().getX() >> 4;
        int pcz = mc.player.getBlockPos().getZ() >> 4;
        int range = outlineRange.intValue();
        for (ChunkInfo c : ChunkTracker.get().snapshot()) {
            if (c.status == ChunkInfo.Status.NEW) {
                n++;
                if (Math.abs(c.x - pcx) <= range && Math.abs(c.z - pcz) <= range) nearby.add(c);
            } else if (c.status == ChunkInfo.Status.OLD) {
                o++;
            }
        }
        newCount = n;
        oldCount = o;
        newNearby = nearby;
    }

    private int mapColor(ChunkInfo c) {
        if (c.status == ChunkInfo.Status.NEW) return NEW_COLOR;
        if (c.status == ChunkInfo.Status.OLD && showOld.on()) return OLD_COLOR;
        return 0;
    }

    @Override
    protected void onHud(DrawContext c) {
        if (map.on()) {
            ChunkMap.draw(c, "NewChunks  new " + newCount + " / old " + oldCount, radius.intValue(), cell.intValue(), this::mapColor);
        }
        if (outline.on() && !newNearby.isEmpty()) {
            ChunkOutline.draw(c, new ArrayList<>(newNearby), ch -> NEW_COLOR, outlineRange.intValue(), 16);
        }
    }
}
