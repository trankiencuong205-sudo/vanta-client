package dev.vanta;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import dev.vanta.core.Category;
import dev.vanta.core.Module;
import dev.vanta.core.ModuleManager;
import dev.vanta.data.WaypointManager;
import dev.vanta.modules.world.Search;
import dev.vanta.modules.world.Waypoints;
import dev.vanta.util.Keys;
import dev.vanta.util.Notifier;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/** Chat commands: /vanta help | list | toggle | bind | wp ... | search ... */
public final class Commands {
    private Commands() {
    }

    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> dispatcher.register(build()));
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> literal(String name) {
        return ClientCommandManager.literal(name);
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> build() {
        LiteralArgumentBuilder<FabricClientCommandSource> root = literal("vanta");

        root.executes(ctx -> {
            help();
            return 1;
        });
        root.then(literal("help").executes(ctx -> {
            help();
            return 1;
        }));

        root.then(literal("list").executes(ctx -> {
            for (Category cat : Category.values()) {
                StringBuilder sb = new StringBuilder(cat.label).append(": ");
                for (Module m : ModuleManager.get().inCategory(cat)) {
                    sb.append(m.isEnabled() ? "§a" : "§7").append(m.name).append("§f ");
                }
                Notifier.chat(sb.toString());
            }
            return 1;
        }));

        root.then(literal("toggle")
                .then(ClientCommandManager.argument("module", StringArgumentType.word()).executes(ctx -> {
                    Module m = find(StringArgumentType.getString(ctx, "module"));
                    if (m == null) {
                        Notifier.chat("Unknown module. Use /vanta list");
                    } else {
                        m.toggle();
                    }
                    return 1;
                })));

        root.then(literal("bind")
                .then(ClientCommandManager.argument("module", StringArgumentType.word())
                        .then(ClientCommandManager.argument("key", StringArgumentType.word()).executes(ctx -> {
                            Module m = find(StringArgumentType.getString(ctx, "module"));
                            if (m == null) {
                                Notifier.chat("Unknown module. Use /vanta list");
                                return 1;
                            }
                            String keyName = StringArgumentType.getString(ctx, "key");
                            int key = parseKey(keyName);
                            if (key == -2) {
                                Notifier.chat("Unknown key '" + keyName + "'. Try a letter, a digit, F1-F12 or 'none'.");
                                return 1;
                            }
                            m.setKey(key);
                            VantaClient.requestSave();
                            Notifier.chat(m.name + " bound to " + Keys.name(key));
                            return 1;
                        }))));

        LiteralArgumentBuilder<FabricClientCommandSource> wp = literal("wp");
        wp.then(literal("add").then(ClientCommandManager.argument("name", StringArgumentType.greedyString()).executes(ctx -> {
            ModuleManager.get().get(Waypoints.class).addNamed(StringArgumentType.getString(ctx, "name"));
            return 1;
        })));
        wp.then(literal("remove").then(ClientCommandManager.argument("name", StringArgumentType.greedyString()).executes(ctx -> {
            boolean ok = WaypointManager.get().remove(StringArgumentType.getString(ctx, "name"));
            Notifier.chat(ok ? "Waypoint removed" : "No waypoint with that name here");
            return 1;
        })));
        wp.then(literal("list").executes(ctx -> {
            List<WaypointManager.Waypoint> list = WaypointManager.get().here();
            if (list.isEmpty()) Notifier.chat("No waypoints in this dimension");
            for (WaypointManager.Waypoint w : list) {
                Notifier.chat(w.name + ": " + w.x + " " + w.y + " " + w.z);
            }
            return 1;
        }));
        wp.then(literal("clear").executes(ctx -> {
            WaypointManager.get().clearHere();
            Notifier.chat("Waypoints of this dimension cleared");
            return 1;
        }));
        root.then(wp);

        root.then(literal("search")
                .then(ClientCommandManager.argument("blocks", StringArgumentType.greedyString()).executes(ctx -> {
                    String spec = StringArgumentType.getString(ctx, "blocks").trim();
                    Search search = ModuleManager.get().get(Search.class);
                    if (spec.equalsIgnoreCase("off")) {
                        search.setEnabled(false);
                    } else {
                        search.setBlocks(spec);
                        if (!search.isEnabled()) search.setEnabled(true);
                        Notifier.chat("Searching for: " + spec);
                    }
                    VantaClient.requestSave();
                    return 1;
                })));

        return root;
    }

    private static void help() {
        Notifier.chat("Open the menu with Right Shift. Commands:");
        Notifier.chat("/vanta list | toggle <module> | bind <module> <key|none>");
        Notifier.chat("/vanta wp add <name> | remove <name> | list | clear");
        Notifier.chat("/vanta search <blocks|off>   e.g. diamond_ore, *chest");
    }

    private static Module find(String name) {
        for (Module m : ModuleManager.get().all()) {
            if (m.name.equalsIgnoreCase(name)) return m;
        }
        return null;
    }

    /** Returns a GLFW key code, -1 for "none", or -2 if the text is not understood. */
    private static int parseKey(String s) {
        String t = s.trim().toUpperCase();
        if (t.equals("NONE") || t.equals("-")) return -1;
        if (t.length() == 1) {
            char ch = t.charAt(0);
            if (ch >= 'A' && ch <= 'Z') return GLFW.GLFW_KEY_A + (ch - 'A');
            if (ch >= '0' && ch <= '9') return GLFW.GLFW_KEY_0 + (ch - '0');
        }
        if (t.matches("F([1-9]|1[0-2])")) {
            return GLFW.GLFW_KEY_F1 + Integer.parseInt(t.substring(1)) - 1;
        }
        switch (t) {
            case "SPACE": return GLFW.GLFW_KEY_SPACE;
            case "TAB": return GLFW.GLFW_KEY_TAB;
            case "INSERT": return GLFW.GLFW_KEY_INSERT;
            case "DELETE": return GLFW.GLFW_KEY_DELETE;
            case "HOME": return GLFW.GLFW_KEY_HOME;
            case "END": return GLFW.GLFW_KEY_END;
            case "PGUP": return GLFW.GLFW_KEY_PAGE_UP;
            case "PGDN": return GLFW.GLFW_KEY_PAGE_DOWN;
            case "UP": return GLFW.GLFW_KEY_UP;
            case "DOWN": return GLFW.GLFW_KEY_DOWN;
            case "LEFT": return GLFW.GLFW_KEY_LEFT;
            case "RIGHT": return GLFW.GLFW_KEY_RIGHT;
            case "LSHIFT": return GLFW.GLFW_KEY_LEFT_SHIFT;
            case "LCTRL": return GLFW.GLFW_KEY_LEFT_CONTROL;
            case "LALT": return GLFW.GLFW_KEY_LEFT_ALT;
            default: return -2;
        }
    }
}
