package dev.vanta.core;

public enum Category {
    COMBAT("COMBAT"),
    MOVEMENT("MOVEMENT"),
    RENDER("RENDER"),
    WORLD("WORLD"),
    MISC("MISC");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
