package dev.vanta.core.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class StringSetting extends Setting<String> {
    public final int maxLength;

    public StringSetting(String name, String description, String def, int maxLength) {
        super(name, description, def);
        this.maxLength = maxLength;
    }

    @Override
    public void set(String v) {
        if (v == null) v = "";
        value = v.length() > maxLength ? v.substring(0, maxLength) : v;
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(value);
    }

    @Override
    public void load(JsonElement element) {
        if (element != null && element.isJsonPrimitive()) {
            set(element.getAsString());
        }
    }
}
