package dev.vanta.core.settings;

import com.google.gson.JsonElement;

/** A button inside a module's settings (for example "Save config"). Not persisted. */
public class ActionSetting extends Setting<Runnable> {
    public ActionSetting(String name, String description, Runnable action) {
        super(name, description, action);
    }

    public void run() {
        try {
            value.run();
        } catch (Throwable t) {
            dev.vanta.VantaClient.LOGGER.warn("Action '{}' failed", name, t);
        }
    }

    @Override
    public JsonElement save() {
        return null;
    }

    @Override
    public void load(JsonElement element) {
    }
}
