package dev.vanta.core;

import dev.vanta.modules.combat.ArmorAlert;
import dev.vanta.modules.combat.AutoEat;
import dev.vanta.modules.combat.AutoTotem;
import dev.vanta.modules.combat.TargetHud;
import dev.vanta.modules.misc.AntiAfk;
import dev.vanta.modules.misc.ConfigModule;
import dev.vanta.modules.misc.DeathPoint;
import dev.vanta.modules.misc.Panic;
import dev.vanta.modules.misc.PlayerAlert;
import dev.vanta.modules.movement.AutoJump;
import dev.vanta.modules.movement.AutoWalk;
import dev.vanta.modules.movement.ElytraSwap;
import dev.vanta.modules.movement.SafeWalk;
import dev.vanta.modules.movement.Sprint;
import dev.vanta.modules.render.Esp;
import dev.vanta.modules.render.Fullbright;
import dev.vanta.modules.render.Hud;
import dev.vanta.modules.render.StorageEsp;
import dev.vanta.modules.render.Zoom;
import dev.vanta.modules.world.BaseFinder;
import dev.vanta.modules.world.ChunkBorders;
import dev.vanta.modules.world.NewChunks;
import dev.vanta.modules.world.Search;
import dev.vanta.modules.world.StashFinder;
import dev.vanta.modules.world.SusChunk;
import dev.vanta.modules.world.Waypoints;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleManager {
    private static final ModuleManager INSTANCE = new ModuleManager();

    private final List<Module> modules = new ArrayList<>();

    public static ModuleManager get() {
        return INSTANCE;
    }

    private ModuleManager() {
    }

    public void init() {
        // COMBAT
        register(new AutoTotem());
        register(new AutoEat());
        register(new TargetHud());
        register(new ArmorAlert());
        // MOVEMENT
        register(new Sprint());
        register(new AutoWalk());
        register(new AutoJump());
        register(new SafeWalk());
        register(new ElytraSwap());
        // RENDER
        register(new Esp());
        register(new StorageEsp());
        register(new Fullbright());
        register(new Zoom());
        register(new Hud());
        // WORLD
        register(new SusChunk());
        register(new NewChunks());
        register(new BaseFinder());
        register(new StashFinder());
        register(new Waypoints());
        register(new ChunkBorders());
        register(new Search());
        // MISC
        register(new AntiAfk());
        register(new PlayerAlert());
        register(new DeathPoint());
        register(new Panic());
        register(new ConfigModule());
    }

    private void register(Module module) {
        modules.add(module);
    }

    public List<Module> all() {
        return Collections.unmodifiableList(modules);
    }

    public List<Module> inCategory(Category category) {
        List<Module> out = new ArrayList<>();
        for (Module m : modules) {
            if (m.category == category) out.add(m);
        }
        return out;
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> type) {
        for (Module m : modules) {
            if (m.getClass() == type) return (T) m;
        }
        throw new IllegalStateException("Module not registered: " + type.getSimpleName());
    }

    public void tick() {
        for (int i = 0; i < modules.size(); i++) {
            Module m = modules.get(i);
            if (m.isEnabled()) m.safeTick();
        }
    }

    public void renderHud(DrawContext context) {
        for (int i = 0; i < modules.size(); i++) {
            Module m = modules.get(i);
            if (m.isEnabled()) m.safeHud(context);
        }
    }

    /** Undoes client-side changes (FOV, effects) when the game closes, without changing the saved state. */
    public void shutdown() {
        for (Module m : modules) m.shutdown();
    }

    public void disableAll() {
        for (Module m : modules) {
            if (m.isEnabled() && !(m instanceof Panic)) m.setEnabled(false, false);
        }
    }
}
