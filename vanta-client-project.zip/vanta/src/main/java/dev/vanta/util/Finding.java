package dev.vanta.util;

import dev.vanta.data.ChunkInfo;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.List;

/** One result of BaseFinder / StashFinder / SusChunk, with coordinates and a human readable reason. */
public final class Finding {
    public final ChunkInfo chunk;
    public final int x;
    public final int y;
    public final int z;
    public final double score;
    public final String reason;
    public double distance;

    public Finding(ChunkInfo chunk, double score, String reason) {
        this.chunk = chunk;
        this.x = chunk.anchorX;
        this.y = chunk.anchorY;
        this.z = chunk.anchorZ;
        this.score = score;
        this.reason = reason;
    }

    public String coords() {
        return x + " " + y + " " + z;
    }

    /** Draws a result list in the left column and projected markers in the world. */
    public static void render(DrawContext c, String title, List<Finding> list, int color, int rows, boolean markers) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        if (rows > 0) {
            int shown = Math.min(rows, list.size());
            int h = 14 + Math.max(1, shown) * 11 + 2;
            int y = HudLayout.allocLeft(h);
            int w = Draw.textWidth(title + " (" + list.size() + ")") + 12;
            String[] lines = new String[shown];
            for (int i = 0; i < shown; i++) {
                Finding f = list.get(i);
                lines[i] = f.coords() + "  " + Math.round(f.distance) + "m  " + f.reason;
                w = Math.max(w, Draw.textWidth(lines[i]) + 12);
            }
            w = Math.min(w, 330);
            c.fill(4, y, 4 + w, y + h, Theme.mul(Theme.PANEL, 0.88f));
            c.fill(4, y, 6, y + h, color);
            Draw.text(c, title + " (" + list.size() + ")", 10, y + 3, color);
            if (shown == 0) {
                Draw.text(c, "nothing found yet", 10, y + 14, Theme.TEXT_DIM);
            }
            for (int i = 0; i < shown; i++) {
                Draw.text(c, trim(lines[i], w - 12), 10, y + 14 + i * 11, Theme.TEXT);
            }
        }

        if (markers && Projection.isReady()) {
            double[] p = new double[3];
            int drawn = 0;
            for (Finding f : list) {
                if (drawn >= 25) break;
                if (!Projection.toScreen(f.x + 0.5, f.y + 0.5, f.z + 0.5, p)) continue;
                int sx = (int) p[0], sy = (int) p[1];
                if (sx < -20 || sy < -20 || sx > Projection.width() + 20 || sy > Projection.height() + 20) continue;
                c.fill(sx - 3, sy - 3, sx + 4, sy + 4, color);
                Draw.outline(c, sx - 4, sy - 4, sx + 5, sy + 5, Theme.alpha(0xFF000000, 200));
                String label = title + " " + Math.round(f.distance) + "m";
                Draw.textCentered(c, label, sx, sy - 16, Theme.TEXT);
                Draw.textCentered(c, f.coords(), sx, sy - 7, Theme.TEXT_DIM);
                drawn++;
            }
        }
    }

    private static String trim(String s, int maxWidth) {
        if (Draw.textWidth(s) <= maxWidth) return s;
        while (s.length() > 4 && Draw.textWidth(s + "...") > maxWidth) {
            s = s.substring(0, s.length() - 1);
        }
        return s + "...";
    }
}
