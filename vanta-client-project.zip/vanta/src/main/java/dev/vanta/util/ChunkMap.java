package dev.vanta.util;

import dev.vanta.data.ChunkInfo;
import dev.vanta.data.ChunkTracker;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.Map;
import java.util.function.ToIntFunction;

/** Small top-down chunk map in the bottom-left corner. One cell = one chunk, the colour comes from the caller. */
public final class ChunkMap {
    private ChunkMap() {
    }

    public static void draw(DrawContext c, String title, int radius, int cell, ToIntFunction<ChunkInfo> colorOf) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        int size = (radius * 2 + 1) * cell;
        int slot = HudLayout.nextMapSlot();
        int x = 6;
        int y = mc.getWindow().getScaledHeight() - 36 - size - slot * (size + 18);

        c.fill(x - 2, y - 14, x + size + 2, y + size + 2, Theme.mul(Theme.PANEL, 0.9f));
        Draw.text(c, title, x + 1, y - 11, Theme.TEXT);

        int pcx = mc.player.getBlockPos().getX() >> 4;
        int pcz = mc.player.getBlockPos().getZ() >> 4;
        Map<Long, ChunkInfo> map = ChunkTracker.get().current();

        for (int dz = -radius; dz <= radius; dz++) {
            for (int dx = -radius; dx <= radius; dx++) {
                int cx1 = x + (dx + radius) * cell;
                int cy1 = y + (dz + radius) * cell;
                ChunkInfo info = map.get(ChunkInfo.key(pcx + dx, pcz + dz));
                int color = 0;
                int base = Theme.alpha(Theme.PANEL_ALT, 255);
                if (info != null) {
                    color = colorOf.applyAsInt(info);
                    if (color == 0 && info.loaded) base = Theme.ROW;
                }
                c.fill(cx1, cy1, cx1 + cell, cy1 + cell, color != 0 ? color : base);
            }
        }
        int mid = x + radius * cell;
        int midY = y + radius * cell;
        Draw.outline(c, mid - 1, midY - 1, mid + cell + 1, midY + cell + 1, Theme.TEXT);
    }
}
