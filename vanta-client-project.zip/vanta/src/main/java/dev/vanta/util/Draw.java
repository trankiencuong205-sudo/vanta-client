package dev.vanta.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Box;

/** 2D drawing helpers built only on DrawContext.fill / drawText. */
public final class Draw {
    private Draw() {
    }

    private static final double[] SEG = new double[4];
    private static final double[] PT = new double[3];
    private static final int MAX_STEPS = 1600;

    public static int textWidth(String s) {
        return MinecraftClient.getInstance().textRenderer.getWidth(s);
    }

    public static void text(DrawContext c, String s, int x, int y, int color) {
        c.drawText(MinecraftClient.getInstance().textRenderer, s, x, y, color, true);
    }

    public static void textCentered(DrawContext c, String s, int cx, int y, int color) {
        text(c, s, cx - textWidth(s) / 2, y, color);
    }

    public static void rect(DrawContext c, int x1, int y1, int x2, int y2, int color) {
        c.fill(x1, y1, x2, y2, color);
    }

    /** Rectangle with 1px clipped corners. */
    public static void rounded(DrawContext c, int x1, int y1, int x2, int y2, int color) {
        c.fill(x1 + 1, y1, x2 - 1, y2, color);
        c.fill(x1, y1 + 1, x2, y2 - 1, color);
    }

    public static void outline(DrawContext c, int x1, int y1, int x2, int y2, int color) {
        c.fill(x1, y1, x2, y1 + 1, color);
        c.fill(x1, y2 - 1, x2, y2, color);
        c.fill(x1, y1 + 1, x1 + 1, y2 - 1, color);
        c.fill(x2 - 1, y1 + 1, x2, y2 - 1, color);
    }

    /** Clips the segment to the screen (with a margin) and draws it with 1..n pixel squares. */
    public static void line(DrawContext c, double x1, double y1, double x2, double y2, int color, int thickness) {
        double margin = 40;
        double minX = -margin, minY = -margin;
        double maxX = Projection.width() + margin, maxY = Projection.height() + margin;

        // Liang-Barsky clipping
        double dx = x2 - x1, dy = y2 - y1;
        double t0 = 0, t1 = 1;
        double[] p = {-dx, dx, -dy, dy};
        double[] q = {x1 - minX, maxX - x1, y1 - minY, maxY - y1};
        for (int i = 0; i < 4; i++) {
            if (p[i] == 0) {
                if (q[i] < 0) return;
            } else {
                double r = q[i] / p[i];
                if (p[i] < 0) {
                    if (r > t1) return;
                    if (r > t0) t0 = r;
                } else {
                    if (r < t0) return;
                    if (r < t1) t1 = r;
                }
            }
        }
        double ax = x1 + dx * t0, ay = y1 + dy * t0;
        double bx = x1 + dx * t1, by = y1 + dy * t1;

        int t = Math.max(1, thickness);
        double ddx = bx - ax, ddy = by - ay;
        if (Math.abs(ddx) < 0.75) {
            int x = (int) Math.round((ax + bx) / 2);
            c.fill(x, (int) Math.floor(Math.min(ay, by)), x + t, (int) Math.ceil(Math.max(ay, by)) + t, color);
            return;
        }
        if (Math.abs(ddy) < 0.75) {
            int y = (int) Math.round((ay + by) / 2);
            c.fill((int) Math.floor(Math.min(ax, bx)), y, (int) Math.ceil(Math.max(ax, bx)) + t, y + t, color);
            return;
        }
        double len = Math.max(Math.abs(ddx), Math.abs(ddy));
        int steps = (int) Math.min(MAX_STEPS, Math.ceil(len / t));
        if (steps < 1) steps = 1;
        for (int i = 0; i <= steps; i++) {
            double f = i / (double) steps;
            int x = (int) Math.round(ax + ddx * f);
            int y = (int) Math.round(ay + ddy * f);
            c.fill(x, y, x + t, y + t, color);
        }
    }

    /** Draws a world-space line (clipped against the camera's near plane). */
    public static void worldLine(DrawContext c, double x1, double y1, double z1, double x2, double y2, double z2,
                                 int color, int thickness) {
        if (Projection.line(x1, y1, z1, x2, y2, z2, SEG)) {
            line(c, SEG[0], SEG[1], SEG[2], SEG[3], color, thickness);
        }
    }

    /** Full 3D wireframe of a box (12 edges). */
    public static void box3d(DrawContext c, Box b, int color) {
        double x1 = b.minX, y1 = b.minY, z1 = b.minZ, x2 = b.maxX, y2 = b.maxY, z2 = b.maxZ;
        worldLine(c, x1, y1, z1, x2, y1, z1, color, 1);
        worldLine(c, x2, y1, z1, x2, y1, z2, color, 1);
        worldLine(c, x2, y1, z2, x1, y1, z2, color, 1);
        worldLine(c, x1, y1, z2, x1, y1, z1, color, 1);
        worldLine(c, x1, y2, z1, x2, y2, z1, color, 1);
        worldLine(c, x2, y2, z1, x2, y2, z2, color, 1);
        worldLine(c, x2, y2, z2, x1, y2, z2, color, 1);
        worldLine(c, x1, y2, z2, x1, y2, z1, color, 1);
        worldLine(c, x1, y1, z1, x1, y2, z1, color, 1);
        worldLine(c, x2, y1, z1, x2, y2, z1, color, 1);
        worldLine(c, x2, y1, z2, x2, y2, z2, color, 1);
        worldLine(c, x1, y1, z2, x1, y2, z2, color, 1);
    }

    /**
     * Screen-space bounds of a world box, or null if any corner is behind the camera.
     * Result = {minX, minY, maxX, maxY}.
     */
    public static double[] bounds(Box b) {
        double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (int i = 0; i < 8; i++) {
            double x = (i & 1) == 0 ? b.minX : b.maxX;
            double y = (i & 2) == 0 ? b.minY : b.maxY;
            double z = (i & 4) == 0 ? b.minZ : b.maxZ;
            if (!Projection.toScreen(x, y, z, PT)) return null;
            minX = Math.min(minX, PT[0]);
            minY = Math.min(minY, PT[1]);
            maxX = Math.max(maxX, PT[0]);
            maxY = Math.max(maxY, PT[1]);
        }
        return new double[]{minX, minY, maxX, maxY};
    }

    /** Outlined (and optionally filled) 2D box around a world box. Returns the bounds, or null if not visible. */
    public static double[] box2d(DrawContext c, Box b, int color, int fillColor) {
        double[] r = bounds(b);
        if (r == null) return null;
        if (r[2] < 0 || r[0] > Projection.width() || r[3] < 0 || r[1] > Projection.height()) return null;
        int x1 = (int) Math.floor(r[0]), y1 = (int) Math.floor(r[1]);
        int x2 = (int) Math.ceil(r[2]), y2 = (int) Math.ceil(r[3]);
        if (x2 - x1 > 4000 || y2 - y1 > 4000) return null;
        if (x2 - x1 < 3) x2 = x1 + 3;
        if (y2 - y1 < 3) y2 = y1 + 3;
        if ((fillColor >>> 24) != 0) c.fill(x1, y1, x2, y2, fillColor);
        outline(c, x1, y1, x2, y2, color);
        return r;
    }
}
