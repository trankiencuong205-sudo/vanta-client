package dev.vanta;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.vanta.core.Module;
import dev.vanta.core.ModuleManager;
import dev.vanta.core.settings.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Saves module state, key binds and settings to config/vanta/config.json. */
public final class Config {
    private Config() {
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("vanta").resolve("config.json");
    private static final List<Module> WANT_ENABLED = new ArrayList<>();

    public static synchronized void save() {
        try {
            JsonObject root = new JsonObject();
            JsonObject modules = new JsonObject();
            for (Module m : ModuleManager.get().all()) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.isEnabled());
                o.addProperty("key", m.getKey());
                JsonObject settings = new JsonObject();
                for (Setting<?> s : m.settings) {
                    JsonElement e = s.save();
                    if (e != null) settings.add(s.name, e);
                }
                o.add("settings", settings);
                modules.add(m.name, o);
            }
            root.add("modules", modules);
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(root), StandardCharsets.UTF_8);
        } catch (Throwable t) {
            VantaClient.LOGGER.warn("Could not save config", t);
        }
    }

    public static synchronized boolean load() {
        WANT_ENABLED.clear();
        if (!Files.exists(FILE)) return false;
        try (Reader r = Files.newBufferedReader(FILE, StandardCharsets.UTF_8)) {
            JsonObject root = GSON.fromJson(r, JsonObject.class);
            if (root == null || !root.has("modules")) return false;
            JsonObject modules = root.getAsJsonObject("modules");
            for (Module m : ModuleManager.get().all()) {
                if (!modules.has(m.name)) continue;
                JsonObject o = modules.getAsJsonObject(m.name);
                if (o.has("key")) m.setKey(o.get("key").getAsInt());
                if (o.has("settings")) {
                    JsonObject settings = o.getAsJsonObject("settings");
                    for (Setting<?> s : m.settings) {
                        if (settings.has(s.name)) {
                            try {
                                s.load(settings.get(s.name));
                            } catch (Throwable t) {
                                VantaClient.LOGGER.warn("Bad value for {}.{}", m.name, s.name);
                            }
                        }
                    }
                }
                if (o.has("enabled") && o.get("enabled").getAsBoolean()) WANT_ENABLED.add(m);
            }
            return true;
        } catch (Throwable t) {
            VantaClient.LOGGER.warn("Could not read config, using defaults", t);
            return false;
        }
    }

    /** Re-enables modules that were on when the game was closed. Runs once a world is available. */
    public static void applyEnabledState() {
        for (Module m : WANT_ENABLED) {
            m.setEnabled(true, false);
        }
        WANT_ENABLED.clear();
    }

    public static void resetAll() {
        for (Module m : ModuleManager.get().all()) {
            for (Setting<?> s : m.settings) s.reset();
            m.setKey(-1);
        }
        save();
    }
}
