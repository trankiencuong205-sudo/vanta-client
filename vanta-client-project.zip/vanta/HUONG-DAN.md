# Vanta Client (Minecraft 1.21.11, Fabric)

Client có ClickGUI (nhấn **Right Shift**), 5 tab: COMBAT, MOVEMENT, RENDER, WORLD, MISC.

> Project này **chưa được biên dịch thử**. File `.jar` được tạo bằng cách cho GitHub build giúp (miễn phí, làm theo bên dưới).
> Nếu build báo lỗi, gửi phần lỗi cho mình để sửa.

## Cách lấy file .jar (không cần biết code, không cài gì)

1. Vào https://github.com và tạo tài khoản (miễn phí).
2. Bấm dấu **+** góc phải trên → **New repository**. Đặt tên `vanta-client`, chọn **Private**, bấm **Create repository**.
3. Giải nén file ZIP này ra một thư mục.
4. Trong trang repo vừa tạo, bấm **uploading an existing file**, kéo thả **toàn bộ nội dung bên trong thư mục `vanta`**
   (các thư mục `src`, `scripts`, `.github`, và các file `build.gradle`, `settings.gradle`, `gradle.properties`...) vào trang rồi bấm **Commit changes**.
   - Nếu thư mục `.github` không lên (thư mục ẩn): bấm **Add file → Create new file**, gõ tên `.github/workflows/build.yml`,
     rồi dán nội dung file `github-workflow/build.yml` trong ZIP vào và bấm **Commit changes**.
5. Bấm tab **Actions**. Workflow **Build Vanta Client** sẽ tự chạy (khoảng 3 đến 8 phút). Nếu không tự chạy: chọn nó rồi bấm **Run workflow**.
6. Khi có dấu tích xanh ✅: bấm vào lần chạy đó, kéo xuống mục **Artifacts**, tải **vanta-client-jar**. Giải nén sẽ ra file `vanta-client-1.0.0.jar`.
7. Nếu có dấu ❌: bấm vào lần chạy đó, copy phần **"Build failed - copy the text below"** (ở trang Summary) hoặc tải artifact **build-log**, rồi gửi cho mình.

## Cài vào game

1. Cài **Fabric Loader** cho Minecraft **1.21.11**: https://fabricmc.net/use/installer/
2. Tải **Fabric API** cho 1.21.11 (Modrinth: `fabric-api`) và bỏ vào thư mục `mods`.
3. Bỏ `vanta-client-1.0.0.jar` vào thư mục `mods` (Windows: `%appdata%\.minecraft\mods`).
4. Vào game, nhấn **Right Shift** để mở menu.

## Dùng menu

- Chuột trái vào module: bật/tắt. Chuột phải (hoặc mũi tên `v`): mở cài đặt riêng của module.
- Ô phím bên phải mỗi module: bấm rồi nhấn phím để gán (nhấn Delete để xóa). Mô tả hiện ở thanh dưới cùng khi rê chuột.
- Lệnh chat: `/vanta help`, `/vanta toggle <module>`, `/vanta bind <module> <phím>`, `/vanta wp add <tên>`, `/vanta search diamond_ore, *chest`.
- Cấu hình lưu ở `config/vanta/config.json`, waypoint ở `config/vanta/waypoints.json`.

## Danh sách module

**RENDER**: ESP, StorageESP, Fullbright, Zoom, HUD
**WORLD**: SusChunk, NewChunks, BaseFinder, StashFinder, Waypoints, ChunkBorders, Search
**MOVEMENT**: Sprint, AutoWalk, AutoJump, SafeWalk, ElytraSwap
**COMBAT**: AutoTotem, AutoEat, TargetHUD, ArmorAlert
**MISC**: AntiAFK, PlayerAlert, DeathPoint, Panic, Config

## Các module WORLD hoạt động thế nào (và giới hạn)

Tất cả chỉ dùng dữ liệu mà client đã nhận từ server (block entity, block, chất lỏng của các chunk đã tải). Không thể thấy chunk ngoài tầm render.

- **NewChunks**: chunk có chất lỏng đã chảy ổn định trong dữ liệu chunk = *cũ*; chunk có nguồn chất lỏng cạnh không khí chưa chảy, hoặc chất lỏng bắt đầu chảy ngay sau khi chunk tải = *mới*. Đây là phương pháp suy đoán, không chính xác 100% (chunk không có chất lỏng thì không kết luận được).
- **SusChunk**: chấm điểm chunk theo vệt di chuyển (chunk cũ nằm giữa chunk mới), số block do người chơi đặt (bê tông, redstone...), tiện ích (giường, lò, phễu...) và cụm rương.
- **BaseFinder**: điểm theo beacon, ender chest, bàn phù phép, giường, lò, phễu, biển, rương và block nhân tạo. Có lọc điểm tối thiểu, khoảng cách và loại công trình. Làng/pháo đài tự nhiên có thể bị nhận nhầm nếu để điểm thấp.
- **StashFinder**: đếm rương, thùng, shulker trong cụm 3x3 chunk, lọc theo số lượng tối thiểu và khoảng cách.
- Cả hai có nút **Add waypoints** và **Print to chat** để lấy tọa độ.

## Lưu ý

- Dùng trên server cho phép các tiện ích kiểu này. Nhiều server cấm và sẽ ban.
- Overlay (ESP, tọa độ trên màn hình...) được tự tính trên lớp HUD nên có thể lệch nhẹ khi FOV thay đổi mạnh (ví dụ khi dùng thuốc tốc độ).
